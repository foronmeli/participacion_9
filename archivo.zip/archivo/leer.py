nombres_leidos = []
with open("nombres.txt", "r") as archivo:
    for linea in archivo:
        nombres_leidos.append(linea.strip())

print("nombres leidos desde el archivo son: ", nombres_leidos)